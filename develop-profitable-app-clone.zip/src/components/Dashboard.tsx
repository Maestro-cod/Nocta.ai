import { useEffect, useMemo, useState } from "react";

type Prospect = { id: string; name: string; company: string; email: string; website: string; status: "new" | "contacted" | "replied" | "meeting" | "won"; score: number; owner: string; lastTouch: string };
type Campaign = { id: string; name: string; sent: number; opens: number; replies: number; meetings: number; status: "running" | "paused" | "draft"; tone: string; };
type SequenceStep = { day: number; channel: "Email" | "LinkedIn" | "Twitter"; template: string; };

const LS_KEY = "nocta.dashboard.v1";

function uid() { return Math.random().toString(36).slice(2, 9); }
function today() { return new Date().toISOString().slice(0, 10); }

function seedState() {
  const p: Prospect[] = [
    { id: uid(), name: "Alex Kim", company: "Linear", email: "alex@linear.app", website: "linear.app", status: "meeting", score: 84, owner: "you", lastTouch: today() },
    { id: uid(), name: "Maria Lopes", company: "Ramp", email: "maria@ramp.com", website: "ramp.com", status: "replied", score: 76, owner: "you", lastTouch: today() },
    { id: uid(), name: "Jordan Park", company: "Figma", email: "jordan@figma.com", website: "figma.com", status: "contacted", score: 68, owner: "you", lastTouch: today() },
    { id: uid(), name: "Sam Rivera", company: "Notion", email: "sam@notion.so", website: "notion.so", status: "new", score: 52, owner: "you", lastTouch: today() },
    { id: uid(), name: "Priya Singh", company: "Stripe", email: "priya@stripe.com", website: "stripe.com", status: "won", score: 99, owner: "you", lastTouch: today() },
    { id: uid(), name: "Omar H.", company: "Vercel", email: "omar@vercel.com", website: "vercel.com", status: "contacted", score: 71, owner: "you", lastTouch: today() },
  ];
  const c: Campaign[] = [
    { id: uid(), name: "Series B SaaS · outbound", sent: 4820, opens: 1844, replies: 412, meetings: 58, status: "running", tone: "Friendly & direct" },
    { id: uid(), name: "Fintech · referral intro", sent: 1120, opens: 612, replies: 84, meetings: 19, status: "running", tone: "Professional" },
    { id: uid(), name: "Design tool · cold → warm", sent: 980, opens: 310, replies: 31, meetings: 7, status: "paused", tone: "Warm & curious" },
    { id: uid(), name: "Founder follow-up", sent: 0, opens: 0, replies: 0, meetings: 0, status: "draft", tone: "Bold & short" },
  ];
  const s: SequenceStep[] = [
    { day: 1, channel: "Email", template: "Personalized opener — reference recent content" },
    { day: 3, channel: "Email", template: "Short follow-up with social proof" },
    { day: 5, channel: "LinkedIn", template: "Connection request + 1-line note" },
    { day: 8, channel: "Email", template: "Case study — relevant company" },
    { day: 12, channel: "Email", template: "Breakup email" },
  ];
  return { prospects: p, campaigns: c, sequence: s, aiUsage: 42, aiLimit: 200, plan: "Growth (annual)" };
}

function load() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return seedState();
    const d = JSON.parse(raw);
    return { ...seedState(), ...d };
  } catch {
    return seedState();
  }
}

export default function Dashboard({ go }: { go: (h: string) => void }) {
  const [data, setData] = useState(load);
  const [tab, setTab] = useState<"overview" | "campaigns" | "prospects" | "sequences" | "compose" | "settings">("overview");

  useEffect(() => { localStorage.setItem(LS_KEY, JSON.stringify(data)); }, [data]);

  const totals = useMemo(() => ({
    sent: data.campaigns.reduce((a: number, c: Campaign) => a + c.sent, 0),
    opens: data.campaigns.reduce((a: number, c: Campaign) => a + c.opens, 0),
    replies: data.campaigns.reduce((a: number, c: Campaign) => a + c.replies, 0),
    meetings: data.campaigns.reduce((a: number, c: Campaign) => a + c.meetings, 0),
    pipeline: data.prospects.filter((p: Prospect) => p.status !== "new").length * 18400,
  }), [data]);

  return (
    <div className="min-h-screen bg-ink-950 text-white">
      <Shell go={go} tab={tab} setTab={setTab}>
        {tab === "overview" && <Overview data={data} setData={setData} totals={totals} />}
        {tab === "campaigns" && <Campaigns data={data} setData={setData} />}
        {tab === "prospects" && <Prospects data={data} setData={setData} />}
        {tab === "sequences" && <Sequences data={data} setData={setData} />}
        {tab === "compose" && <Composer data={data} setData={setData} />}
        {tab === "settings" && <Settings data={data} setData={setData} />}
      </Shell>
    </div>
  );
}

function Shell({ go, tab, setTab, children }: any) {
  const items: [string, string, string][] = [
    ["overview","Overview","📊"],
    ["campaigns","Campaigns","📣"],
    ["prospects","Prospects","👥"],
    ["sequences","Sequences","🔁"],
    ["compose","AI Composer","🧠"],
    ["settings","Settings","⚙️"],
  ];
  return (
    <div className="mx-auto max-w-7xl flex gap-4 p-4">
      {/* Sidebar */}
      <aside className="hidden md:flex w-60 shrink-0 flex-col gap-1 sticky top-4 self-start">
        <button onClick={() => go("home")} className="flex items-center gap-2 mb-2 px-2">
          <div className="relative h-8 w-8 rounded-lg overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-nocta-400 to-accent" />
            <span className="relative text-white font-black text-sm grid place-items-center h-full">N</span>
          </div>
          <span className="font-black">Nocta<span className="text-nocta-300">.ai</span></span>
        </button>
        {items.map(([k, l, i]) => (
          <button key={k} onClick={() => setTab(k as any)} className={`flex items-center gap-3 px-3 h-10 rounded-xl text-sm ${tab===k ? "bg-white/10 text-white font-semibold" : "text-white/70 hover:bg-white/5"}`}>
            <span>{i}</span><span>{l}</span>
            {k==="compose" && <span className="ml-auto text-[10px] bg-nocta-500 text-white px-1.5 py-0.5 rounded-full">NEW</span>}
          </button>
        ))}
        <div className="mt-4 glass rounded-2xl p-4">
          <div className="text-xs font-semibold text-white/60 uppercase tracking-wider">Plan</div>
          <div className="font-bold mt-1">Growth (annual)</div>
          <div className="text-[11px] text-white/60">25,000 emails / mo</div>
          <button className="mt-3 w-full h-8 rounded-lg bg-white text-black text-xs font-semibold">Upgrade →</button>
        </div>
      </aside>

      {/* Mobile tabs */}
      <div className="md:hidden fixed bottom-3 left-3 right-3 z-30 glass rounded-2xl p-1.5 flex overflow-x-auto no-scrollbar">
        {items.map(([k, l, i]) => (
          <button key={k} onClick={() => setTab(k as any)} className={`shrink-0 px-3 h-9 rounded-xl text-xs ${tab===k ? "bg-white text-black font-bold" : "text-white/80"}`}>
            <span className="mr-1">{i}</span>{l}
          </button>
        ))}
      </div>

      {/* Main */}
      <main className="flex-1 min-w-0 pb-24 md:pb-0">
        <PageHeader tab={tab} />
        {children}
      </main>
    </div>
  );
}

function PageHeader({ tab }: { tab: string }) {
  return (
    <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
      <div>
        <div className="text-xs text-white/50">Dashboard / {tab}</div>
        <h1 className="text-2xl md:text-3xl font-black capitalize">{tab}</h1>
      </div>
      <div className="flex items-center gap-2">
        <div className="hidden sm:flex items-center gap-2 glass rounded-xl px-3 h-10 text-xs text-white/70">
          <kbd>⌘</kbd><kbd>K</kbd> Search · docs · actions
        </div>
        <button className="h-10 px-4 rounded-xl glass text-sm">Invite teammate</button>
        <button className="h-10 px-4 rounded-xl btn-primary text-sm font-semibold">+ New campaign</button>
      </div>
    </div>
  );
}

function Kpi({ label, value, delta, good = true }: any) {
  return (
    <div className="glass rounded-2xl p-5 relative overflow-hidden">
      <div className="text-xs uppercase tracking-widest text-white/50 font-semibold">{label}</div>
      <div className="mt-2 text-3xl font-black">{value}</div>
      <div className={`mt-1 text-xs font-semibold ${good ? "text-mint" : "text-amber"}`}>{delta}</div>
    </div>
  );
}

function Sparkline({ color = "#8b5bff", height = 80 }: { color?: string; height?: number }) {
  const pts = useMemo(() => {
    const arr: number[] = [];
    let v = 40;
    for (let i = 0; i < 30; i++) { v += (Math.sin(i / 2) * 6) + (Math.random() * 10 - 5); arr.push(Math.max(10, Math.min(90, v))); }
    return arr;
  }, []);
  const path = pts.map((y, i) => `${i === 0 ? "M" : "L"} ${(i / (pts.length - 1)) * 300} ${100 - y}`).join(" ");
  const area = `${path} L 300 100 L 0 100 Z`;
  return (
    <svg viewBox={`0 0 300 100`} preserveAspectRatio="none" className="w-full" style={{ height }}>
      <defs>
        <linearGradient id={`g_${color}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.55" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#g_${color})`} />
      <path d={path} fill="none" stroke={color} strokeWidth="2" />
    </svg>
  );
}

function BarChart() {
  const days = useMemo(() => Array.from({ length: 14 }, () => Math.floor(Math.random() * 400) + 60), []);
  const max = Math.max(...days);
  return (
    <div className="flex items-end gap-1.5 h-40">
      {days.map((v, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
          <div className="w-full rounded-t-md bg-gradient-to-t from-nocta-600 to-nocta-300" style={{ height: `${(v / max) * 100}%` }} />
          <div className="text-[9px] text-white/40">{String(i + 1).padStart(2, "0")}</div>
        </div>
      ))}
    </div>
  );
}

function Overview({ data, totals }: any) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Kpi label="Emails sent" value={totals.sent.toLocaleString()} delta="+18% vs last wk" />
        <Kpi label="Open rate" value={`${(totals.opens / Math.max(1, totals.sent) * 100).toFixed(1)}%`} delta="+4.2 pts" />
        <Kpi label="Replies" value={totals.replies.toLocaleString()} delta="+22 replies" />
        <Kpi label="Meetings" value={totals.meetings} delta="+9 booked" />
        <Kpi label="Pipeline $" value={`$${(totals.pipeline/1000).toFixed(1)}K`} delta="+$124K this wk" />
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 glass rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="font-bold">Outbound performance</div>
              <div className="text-xs text-white/60">Last 30 days — replies per day</div>
            </div>
            <div className="flex gap-1 text-[11px]">
              {["7d","14d","30d","90d"].map((t,i) => (
                <button key={t} className={`px-2 h-7 rounded-md border ${i===2 ? "bg-white text-black border-white" : "bg-white/5 border-white/10 text-white/70"}`}>{t}</button>
              ))}
            </div>
          </div>
          <Sparkline color="#8b5bff" height={180} />
          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
            {[["Replies","9.4%","+1.8pt"],["Open rate","38.2%","+2.1pt"],["Click rate","6.8%","+0.4pt"],["Bounce","1.1%","-0.3pt"]].map(([k,v,d])=>(
              <div key={k} className="rounded-xl bg-white/5 border border-white/10 p-3"><div className="text-[11px] text-white/60">{k}</div><div className="text-lg font-black">{v}</div><div className="text-[11px] text-mint">{d}</div></div>
            ))}
          </div>
        </div>

        <div className="glass rounded-2xl p-5">
          <div className="font-bold">Top campaigns</div>
          <div className="text-xs text-white/60">By reply volume</div>
          <div className="mt-4 space-y-3">
            {data.campaigns.slice(0, 4).map((c: Campaign) => (
              <div key={c.id} className="flex items-center gap-3">
                <div className={`h-9 w-9 rounded-lg grid place-items-center text-sm ${c.status==="running" ? "bg-mint/20 text-mint" : c.status==="paused" ? "bg-amber/20 text-amber" : "bg-white/5 text-white/60"}`}>▶</div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold truncate">{c.name}</div>
                  <div className="text-[11px] text-white/60">{c.replies} replies · {c.status}</div>
                </div>
                <div className="text-sm font-bold">{(c.replies/Math.max(1,c.sent)*100).toFixed(1)}%</div>
              </div>
            ))}
          </div>
          <div className="mt-5 pt-4 border-t border-white/10">
            <div className="text-xs text-white/60">Weekly emails sent</div>
            <div className="mt-2"><BarChart /></div>
          </div>
        </div>
      </div>

      {/* Activity feed */}
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 glass rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="font-bold">Prospect activity</div>
            <button className="text-xs text-white/60">View all</button>
          </div>
          <div className="divide-y divide-white/5">
            {data.prospects.slice(0, 6).map((p: Prospect) => (
              <div key={p.id} className="py-3 flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-gradient-to-br from-nocta-400 to-accent grid place-items-center text-sm font-bold">{p.name[0]}</div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold truncate">{p.name} · <span className="text-white/60 font-normal">{p.company}</span></div>
                  <div className="text-[11px] text-white/60">{p.email}</div>
                </div>
                <span className={`text-[11px] rounded-full px-2 py-1 ${p.status==="won" ? "bg-mint/20 text-mint" : p.status==="meeting" ? "bg-nocta-500/20 text-nocta-200" : p.status==="replied" ? "bg-accent/20 text-accent" : p.status==="contacted" ? "bg-white/10 text-white/80" : "bg-white/5 text-white/60"}`}>{p.status}</span>
                <span className="text-sm font-black w-10 text-right">{p.score}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-2xl p-5">
          <div className="font-bold">AI usage</div>
          <div className="text-xs text-white/60">Resets in 18 days</div>
          <div className="mt-4 text-4xl font-black grad-text">{data.aiUsage} <span className="text-white/50 text-base">/ {data.aiLimit}</span></div>
          <div className="mt-2 h-2 rounded-full bg-white/10 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-nocta-400 to-accent" style={{ width: `${(data.aiUsage / data.aiLimit) * 100}%` }} />
          </div>
          <div className="mt-5 space-y-2 text-sm">
            {[["Emails written", 84], ["Subjects A/B", 29], ["ICP lookups", 14]].map(([k,v]) => (
              <div key={k as string} className="flex items-center justify-between text-white/80"><span>{k}</span><span className="font-bold">{v}</span></div>
            ))}
          </div>
          <button className="mt-5 w-full h-10 rounded-xl bg-white text-black font-semibold text-sm">Unlock unlimited →</button>
        </div>
      </div>
    </div>
  );
}

function Campaigns({ data, setData }: any) {
  const [newName, setNewName] = useState("");
  const add = () => {
    if (!newName.trim()) return;
    setData({ ...data, campaigns: [...data.campaigns, { id: uid(), name: newName.trim(), sent: 0, opens: 0, replies: 0, meetings: 0, status: "draft", tone: "Friendly & direct" }] });
    setNewName("");
  };
  const toggle = (id: string) => setData({ ...data, campaigns: data.campaigns.map((c: Campaign) => c.id === id ? { ...c, status: c.status === "running" ? "paused" : "running" } : c) });
  const del = (id: string) => setData({ ...data, campaigns: data.campaigns.filter((c: Campaign) => c.id !== id) });

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-5 flex flex-wrap items-center gap-3">
        <input value={newName} onChange={e=>setNewName(e.target.value)} placeholder="Campaign name (e.g. Series B outbound v2)" className="flex-1 min-w-0 h-11 rounded-xl bg-white/5 border border-white/10 px-3 outline-none focus:border-nocta-400" />
        <button onClick={add} className="h-11 px-5 rounded-xl btn-primary font-semibold">+ Add</button>
        <div className="text-xs text-white/60">Click a row's toggle to run/pause. Changes save automatically.</div>
      </div>
      <div className="glass rounded-2xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-widest text-white/50 bg-white/5">
            <tr>
              <th className="p-4 font-semibold">Campaign</th>
              <th className="p-4 font-semibold">Sent</th>
              <th className="p-4 font-semibold">Opens</th>
              <th className="p-4 font-semibold">Replies</th>
              <th className="p-4 font-semibold">Meetings</th>
              <th className="p-4 font-semibold">Status</th>
              <th className="p-4 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {data.campaigns.map((c: Campaign) => (
              <tr key={c.id} className="hover:bg-white/5">
                <td className="p-4 font-semibold">{c.name}<div className="text-[11px] text-white/50 font-normal">{c.tone}</div></td>
                <td className="p-4">{c.sent.toLocaleString()}</td>
                <td className="p-4">{c.opens}</td>
                <td className="p-4 text-accent font-bold">{c.replies}</td>
                <td className="p-4">{c.meetings}</td>
                <td className="p-4">
                  <span className={`text-[11px] rounded-full px-2 py-1 ${c.status==="running" ? "bg-mint/20 text-mint" : c.status==="paused" ? "bg-amber/20 text-amber" : "bg-white/10 text-white/80"}`}>{c.status}</span>
                </td>
                <td className="p-4 text-right">
                  <div className="inline-flex gap-2">
                    <button onClick={() => toggle(c.id)} className="h-8 px-3 rounded-lg bg-white/5 border border-white/10 text-xs">{c.status==="running" ? "Pause" : "Run"}</button>
                    <button onClick={() => del(c.id)} className="h-8 px-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-xs">Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Prospects({ data, setData }: any) {
  const [f, setF] = useState<Prospect>({ id: uid(), name: "", company: "", email: "", website: "", status: "new", score: 50, owner: "you", lastTouch: today() });
  const [q, setQ] = useState("");
  const add = () => {
    if (!f.name || !f.email) return;
    setData({ ...data, prospects: [{ ...f, id: uid(), score: Math.floor(30 + Math.random() * 60) }, ...data.prospects] });
    setF({ id: uid(), name: "", company: "", email: "", website: "", status: "new", score: 50, owner: "you", lastTouch: today() });
  };
  const setStatus = (id: string, status: Prospect["status"]) => setData({ ...data, prospects: data.prospects.map((p: Prospect) => p.id === id ? { ...p, status } : p) });
  const del = (id: string) => setData({ ...data, prospects: data.prospects.filter((p: Prospect) => p.id !== id) });
  const filtered = data.prospects.filter((p: Prospect) => !q || `${p.name} ${p.company} ${p.email}`.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-5 gap-3 glass rounded-2xl p-5">
        {(["name","company","email","website"] as const).map(k => (
          <input key={k} value={(f as any)[k]} onChange={e => setF({ ...f, [k]: e.target.value })} placeholder={k[0].toUpperCase() + k.slice(1)} className="md:col-span-1 h-11 rounded-xl bg-white/5 border border-white/10 px-3 outline-none focus:border-nocta-400" />
        ))}
        <button onClick={add} className="h-11 rounded-xl btn-primary font-semibold md:col-span-1">+ Add prospect</button>
      </div>
      <div className="flex items-center gap-2">
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Filter by name, company, email…" className="flex-1 h-11 rounded-xl bg-white/5 border border-white/10 px-3 outline-none focus:border-nocta-400" />
        <div className="text-xs text-white/50">{filtered.length} / {data.prospects.length}</div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map((p: Prospect) => (
          <div key={p.id} className="glass rounded-2xl p-5">
            <div className="flex items-start gap-3">
              <div className="h-11 w-11 rounded-full bg-gradient-to-br from-nocta-400 to-accent grid place-items-center font-bold">{p.name[0] ?? "?"}</div>
              <div className="min-w-0 flex-1">
                <div className="font-semibold truncate">{p.name}</div>
                <div className="text-xs text-white/60 truncate">{p.company}</div>
                <div className="text-xs text-white/60 truncate">{p.email}</div>
              </div>
              <button onClick={() => del(p.id)} className="text-xs text-red-300 hover:text-red-200">✕</button>
            </div>
            <div className="mt-3 flex items-center gap-2 flex-wrap">
              <span className="text-[11px] text-white/60">Status:</span>
              {(["new","contacted","replied","meeting","won"] as const).map(s => (
                <button key={s} onClick={() => setStatus(p.id, s)} className={`text-[11px] rounded-full px-2 py-1 border ${p.status===s ? "bg-white text-black border-white font-bold" : "bg-white/5 border-white/10 text-white/70"}`}>{s}</button>
              ))}
            </div>
            <div className="mt-3 h-2 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-mint to-nocta-400" style={{ width: `${p.score}%` }} />
            </div>
            <div className="mt-1 flex items-center justify-between text-[11px] text-white/60">
              <span>Fit score</span><span className="font-bold text-white">{p.score}</span>
            </div>
          </div>
        ))}
        {filtered.length === 0 && <div className="glass rounded-2xl p-10 text-center text-white/60">No prospects match your filter.</div>}
      </div>
    </div>
  );
}

function Sequences({ data, setData }: { data: any; setData: (d: any) => void }) {
  const add = () => setData({ ...data, sequence: [...data.sequence, { day: (data.sequence[data.sequence.length - 1]?.day || 0) + 2, channel: "Email", template: "New step — edit me" }] });
  const upd = (i: number, k: string, v: any) => setData({ ...data, sequence: data.sequence.map((s: any, idx: number) => idx === i ? { ...s, [k]: v } : s) });
  const del = (i: number) => setData({ ...data, sequence: data.sequence.filter((_: any, idx: number) => idx !== i) });
  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-5">
        <div className="font-bold text-lg">7-step outbound sequence</div>
        <div className="text-sm text-white/60">Running on 2,412 contacts · auto-stop on reply</div>
        <div className="mt-4 relative">
          <div className="absolute left-5 top-2 bottom-2 w-0.5 bg-gradient-to-b from-nocta-400/50 via-white/10 to-accent/40" />
          <div className="space-y-3">
            {data.sequence.map((s: SequenceStep, i: number) => (
              <div key={i} className="relative pl-14">
                <div className="absolute left-2 top-2 h-7 w-7 rounded-full bg-gradient-to-br from-nocta-500 to-accent grid place-items-center text-xs font-bold">{s.day}</div>
                <div className="glass rounded-2xl p-4 flex flex-wrap items-start gap-3">
                  <div className="flex items-center gap-2">
                    <span className={`text-[11px] rounded-full px-2 py-1 ${s.channel==="Email" ? "bg-nocta-500/20 text-nocta-200" : s.channel==="LinkedIn" ? "bg-sky-500/20 text-sky-200" : "bg-amber/20 text-amber"}`}>{s.channel}</span>
                    <select value={s.channel} onChange={e => upd(i, "channel", e.target.value)} className="bg-white/5 border border-white/10 rounded-lg text-xs h-8 px-2 outline-none">
                      <option>Email</option><option>LinkedIn</option><option>Twitter</option>
                    </select>
                  </div>
                  <textarea value={s.template} onChange={e => upd(i, "template", e.target.value)} rows={2} className="flex-1 min-w-[260px] bg-white/5 border border-white/10 rounded-xl p-3 text-sm outline-none focus:border-nocta-400" />
                  <button onClick={() => del(i)} className="h-8 px-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-xs">Remove</button>
                </div>
              </div>
            ))}
          </div>
        </div>
        <button onClick={add} className="mt-4 h-10 px-4 rounded-xl glass text-sm">+ Add step</button>
      </div>
    </div>
  );
}

function Composer({ data, setData }: any) {
  const [url, setUrl] = useState("linear.app");
  const [about, setAbout] = useState("Issue tracking for high-performance teams.");
  const [tone, setTone] = useState("Friendly & direct");
  const [length, setLength] = useState("Medium");
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState<string | null>(null);

  const generate = () => {
    setLoading(true);
    setEmail(null);
    const openers = {
      "Friendly & direct": [`Hey ${url.split(".")[0]},`, `Quick one —`, `Heard about ${url.split(".")[0]}, nice.`],
      "Professional & concise": [`Hi ${url.split(".")[0]} team,`, `To your attention —`, `I'm reaching out about ${url.split(".")[0]}.`],
      "Warm & curious": [`Loved what ${url.split(".")[0]} is shipping,`, `Stumbled on ${url.split(".")[0]} — awesome,`, `Your latest ${url.split(".")[0]} launch caught my eye.`],
      "Bold & short": [`This'll be quick.`, `30 seconds.`, `One question.`],
    } as any;
    const bodies = [
      `Most teams building "${about.trim()}" spend 40h/week writing cold email that gets a 3-5% reply rate. We typically 2× that in 30 days.`,
      `${url.split(".")[0]}'s positioning on "${about.trim().slice(0,80)}" looks spot-on — we just helped a similar team add $412K ARR with outbound.`,
      `Quickly scanned ${url.split(".")[0]} and your audience is a near-perfect fit for what we do. Worth a 15-min call?`,
    ];
    const ctas = {
      "Short": "Can I send a 90s video?",
      "Medium": "Worth a 15-min call this week? I promise no pitch.",
      "Long": "Happy to send a 2-page personalized teardown first — no pitch. Then if it's useful, 20 minutes live. Sound fair?",
    } as any;
    setTimeout(() => {
      const o = openers[tone][Math.floor(Math.random() * 3)];
      const b = bodies[Math.floor(Math.random() * bodies.length)];
      const c = ctas[length];
      setEmail(
`Subject: Quick one about ${url}

${o}

${b}

${c}

— Alex
Founder · nocta.ai
(Unsubscribe in 1 click)`.trim()
      );
      setLoading(false);
      setData({ ...data, aiUsage: Math.min(data.aiLimit, data.aiUsage + 1) });
    }, 1000);
  };

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-5 gap-4">
        <div className="glass rounded-2xl p-5 md:col-span-2 space-y-4">
          <div>
            <label className="text-xs uppercase tracking-widest text-white/60 font-semibold">Prospect website</label>
            <input value={url} onChange={e => setUrl(e.target.value)} className="mt-2 w-full h-11 rounded-xl bg-white/5 border border-white/10 px-3 outline-none focus:border-nocta-400" placeholder="acme.com" />
          </div>
          <div>
            <label className="text-xs uppercase tracking-widest text-white/60 font-semibold">What they do</label>
            <textarea value={about} onChange={e => setAbout(e.target.value)} rows={4} className="mt-2 w-full rounded-xl bg-white/5 border border-white/10 p-3 outline-none focus:border-nocta-400" placeholder="Company summary / pitch..." />
          </div>
          <div>
            <label className="text-xs uppercase tracking-widest text-white/60 font-semibold">Tone</label>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {["Friendly & direct","Professional & concise","Warm & curious","Bold & short"].map(t => (
                <button key={t} onClick={() => setTone(t)} className={`h-9 rounded-xl text-xs border ${tone===t ? "bg-white text-black border-white font-semibold" : "bg-white/5 border-white/10 text-white/80"}`}>{t}</button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs uppercase tracking-widest text-white/60 font-semibold">Length</label>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {["Short","Medium","Long"].map(t => (
                <button key={t} onClick={() => setLength(t)} className={`h-9 rounded-xl text-xs border ${length===t ? "bg-white text-black border-white font-semibold" : "bg-white/5 border-white/10 text-white/80"}`}>{t}</button>
              ))}
            </div>
          </div>
          <button onClick={generate} disabled={loading} className="w-full h-12 rounded-xl btn-primary font-semibold shine relative overflow-hidden disabled:opacity-70">
            {loading ? "✍️ Writing..." : "✨ Generate email"}
          </button>
          <div className="text-[11px] text-white/50 text-center">{data.aiUsage} / {data.aiLimit} credits used</div>
        </div>

        <div className="glass rounded-2xl p-5 md:col-span-3">
          <div className="flex items-center justify-between mb-3">
            <div className="flex gap-1.5"><span className="h-3 w-3 rounded-full bg-red-400/70" /><span className="h-3 w-3 rounded-full bg-amber-300/70" /><span className="h-3 w-3 rounded-full bg-mint/70" /></div>
            <div className="text-[11px] text-white/50">nocta.ai — ai composer</div>
          </div>
          <div className="rounded-2xl bg-white/5 border border-white/10 p-5 min-h-[340px] text-[14px] leading-relaxed whitespace-pre-wrap">
            {loading ? (
              <div className="h-full grid place-items-center text-white/60">
                <div className="flex flex-col items-center gap-3">
                  <div className="h-10 w-10 rounded-full border-2 border-white/10 border-t-nocta-400 animate-spin" />
                  Nocta is researching {url}...
                </div>
              </div>
            ) : email ? (<div className="text-white/90">{email}</div>) : (<div className="text-white/40 italic">Your email will appear here. Try the generator — it genuinely works.</div>)}
          </div>
          {email && (
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <button onClick={() => { navigator.clipboard?.writeText(email); alert("Copied to clipboard"); }} className="h-10 px-4 rounded-xl bg-white text-black font-semibold text-sm">Copy</button>
              <button onClick={() => setEmail(null)} className="h-10 px-4 rounded-xl glass text-sm">Clear</button>
              <button onClick={generate} className="h-10 px-4 rounded-xl glass text-sm">↻ Regenerate</button>
              <span className="ml-auto text-[11px] text-white/60">Tone: {tone} · Length: {length} · {email.split(" ").length} words</span>
            </div>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-3">
        {[
          ["Subject suggestions",["Quick one about "+url,"This made me think of you","Your launch made the rounds","30 seconds — promise"]],
          ["A/B variants","Variant A: Social proof opener","Variant B: Teardown approach","Variant C: Personalized line from site"],
          ["Deliverability hints","Avoid spam trigger words","Include one clear CTA","Personalized first line is non-negotiable"],
        ].map(([h, list]) => (
          <div key={h as string} className="glass rounded-2xl p-5">
            <div className="text-xs uppercase tracking-widest text-white/50 font-semibold">{h}</div>
            <ul className="mt-3 space-y-2 text-sm">
              {(list as string[]).map((x, i) => (
                <li key={i} className="flex items-start gap-2 text-white/85"><span className="text-mint mt-1">•</span><span>{x}</span></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

function Settings({ data }: any) {
  const [email, setEmail] = useState("alex@nocta.ai");
  const [sender, setSender] = useState("Alex Kim");
  const [replyTo, setReplyTo] = useState("alex@nocta.ai");
  const [signature, setSignature] = useState("Alex · Founder · nocta.ai");
  const [gdpr, setGdpr] = useState(true);
  const [warmup, setWarmup] = useState(true);
  const [dedicatedIp, setDedicatedIp] = useState(false);
  const [openTracking, setOpenTracking] = useState(true);
  const [clickTracking, setClickTracking] = useState(true);

  const Toggle = ({ v, setV, label, hint }: any) => (
    <div className="flex items-center justify-between py-3 border-b border-white/5">
      <div>
        <div className="font-semibold text-sm">{label}</div>
        <div className="text-xs text-white/60">{hint}</div>
      </div>
      <button onClick={() => setV(!v)} className={`relative h-7 w-12 rounded-full transition ${v ? "bg-nocta-500" : "bg-white/10"}`}>
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${v ? "left-[26px]" : "left-1"}`} />
      </button>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-3 gap-4">
        <div className="glass rounded-2xl p-6 md:col-span-2">
          <div className="font-bold text-lg">Sender identity</div>
          <div className="text-xs text-white/60">What your prospects see in the From field.</div>
          <div className="mt-5 grid sm:grid-cols-2 gap-3">
            {([
              { label: "From name", value: sender, set: setSender },
              { label: "Reply-to", value: replyTo, set: setReplyTo },
              { label: "Email", value: email, set: setEmail },
              { label: "Signature", value: signature, set: setSignature },
            ]).map((f) => (
              <div key={f.label}>
                <label className="text-[11px] uppercase tracking-widest text-white/50 font-semibold">{f.label}</label>
                <input value={f.value} onChange={e => f.set(e.target.value)} className="mt-1 w-full h-10 rounded-xl bg-white/5 border border-white/10 px-3 outline-none focus:border-nocta-400" />
              </div>
            ))}
          </div>
          <div className="mt-5 pt-4 border-t border-white/5">
            <Toggle v={openTracking} setV={setOpenTracking} label="Open tracking (1×1 pixel)" hint="Required for accurate analytics. GDPR-safe." />
            <Toggle v={clickTracking} setV={setClickTracking} label="Link click tracking" hint="Shortens links to track which ones perform." />
            <Toggle v={gdpr} setV={setGdpr} label="GDPR / CAN-SPAM compliance guardrails" hint="Auto-unsubscribe link, honorary list, double opt-in." />
            <Toggle v={warmup} setV={setWarmup} label="Auto inbox warmup" hint="Warms 40+ providers automatically to keep deliverability high." />
            <Toggle v={dedicatedIp} setV={setDedicatedIp} label="Dedicated sending IP" hint="Enterprise-only. Keeps your sender reputation isolated." />
          </div>
        </div>
        <div className="space-y-4">
          <div className="glass rounded-2xl p-6">
            <div className="font-bold text-lg">Billing</div>
            <div className="text-xs text-white/60">Next bill · Feb 1</div>
            <div className="mt-4 text-4xl font-black grad-text">${data.plan==="Growth (annual)"?99:299}</div>
            <div className="text-xs text-white/60">per month · billed annually</div>
            <button className="mt-4 w-full h-10 rounded-xl bg-white text-black font-semibold text-sm">Manage in Stripe</button>
          </div>
          <div className="glass rounded-2xl p-6">
            <div className="font-bold text-lg">Security</div>
            <ul className="mt-3 space-y-2 text-sm text-white/80">
              <li className="flex gap-2"><span className="text-mint">✓</span> SOC 2 Type II</li>
              <li className="flex gap-2"><span className="text-mint">✓</span> GDPR & CCPA ready</li>
              <li className="flex gap-2"><span className="text-mint">✓</span> TLS 1.2+ in transit</li>
              <li className="flex gap-2"><span className="text-mint">✓</span> AES-256 at rest</li>
              <li className="flex gap-2"><span className="text-mint">✓</span> SSO & SCIM (Enterprise)</li>
            </ul>
            <button className="mt-4 w-full h-10 rounded-xl glass text-sm">Download DPA</button>
          </div>
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <div className="font-bold text-lg">Connected domains & providers</div>
        <div className="text-xs text-white/60">Add a custom sending domain to unlock DKIM/SPF and best deliverability.</div>
        <div className="mt-5 grid md:grid-cols-3 gap-3">
          {[["Google Workspace","Connected","text-mint"],["SendGrid","Connected","text-mint"],["Mailgun (dkim=nocta.)","Action needed","text-amber"],["Postmark","Connected","text-mint"],["Amazon SES","Not connected","text-white/50"],["Resend","Not connected","text-white/50"]].map(([n, s, c]) => (
            <div key={n} className="rounded-xl bg-white/5 border border-white/10 p-4">
              <div className="text-sm font-semibold">{n}</div>
              <div className={`text-[11px] font-semibold ${c}`}>{s}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <div className="font-bold text-lg">Team</div>
        <div className="text-xs text-white/60">Invite teammates. Manage roles and permissions.</div>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <input placeholder="teammate@company.com" className="flex-1 min-w-0 h-11 rounded-xl bg-white/5 border border-white/10 px-3 outline-none focus:border-nocta-400" />
          <button className="h-11 px-4 rounded-xl btn-primary font-semibold text-sm">Send invite</button>
        </div>
        <table className="w-full text-sm mt-5">
          <thead className="text-left text-xs uppercase tracking-widest text-white/50 bg-white/5">
            <tr><th className="p-3">Member</th><th className="p-3">Role</th><th className="p-3">Status</th><th className="p-3 text-right">Actions</th></tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {[["Alex Kim","you","Owner","active"],["Sam Rivera","sam@nocta.ai","Admin","active"],["Maria Lopes","maria@nocta.ai","Member","active"],["Omar H.","omar@nocta.ai","Viewer","invited"]].map(([n,e,r,s]) => (
              <tr key={e}>
                <td className="p-3"><div className="flex items-center gap-3"><div className="h-9 w-9 rounded-full bg-gradient-to-br from-nocta-400 to-accent grid place-items-center font-bold">{n[0]}</div><div><div className="font-semibold">{n}</div><div className="text-[11px] text-white/60">{e}</div></div></div></td>
                <td className="p-3"><span className="text-[11px] rounded-full px-2 py-1 bg-white/10">{r}</span></td>
                <td className="p-3"><span className={`text-[11px] rounded-full px-2 py-1 ${s==="active" ? "bg-mint/20 text-mint" : "bg-amber/20 text-amber"}`}>{s}</span></td>
                <td className="p-3 text-right"><button className="text-xs text-white/70 hover:text-white">Manage</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

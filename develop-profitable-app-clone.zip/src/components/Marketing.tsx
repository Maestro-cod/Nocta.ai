import { useState } from "react";

type Props = { go: (h: string) => void; section: string; setSection: (s: string) => void };

function Nav({ go }: { go: (h: string) => void }) {
  return (
    <nav className="fixed top-0 left-0 right-0 z-40">
      <div className="mx-auto max-w-6xl px-4 pt-3">
        <div className="glass rounded-2xl px-4 py-2.5 flex items-center justify-between">
          <a href="#home" onClick={(e)=>{e.preventDefault();go("home");}} className="flex items-center gap-2">
            <div className="relative h-8 w-8 rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-nocta-400 via-nocta-500 to-accent" />
              <span className="relative text-white font-black text-sm grid place-items-center h-full">N</span>
            </div>
            <span className="font-black text-lg">Nocta<span className="text-nocta-300">.ai</span></span>
          </a>
          <div className="hidden md:flex items-center gap-1 text-sm text-white/80">
            {[["Product","product"],["Features","features"],["Demo","demo"],["Customers","customers"],["Affiliates","affiliates"],["Pricing","pricing"]].map(([l, h]) => (
              <a key={h} href={`#${h}`} onClick={(e)=>{e.preventDefault();go(h);}} className="px-3 py-2 rounded-xl hover:bg-white/5">{l}</a>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => go("dashboard")} className="hidden sm:inline-flex h-9 px-3 rounded-xl text-sm text-white/80 hover:text-white">Sign in</button>
            <button onClick={() => go("dashboard")} className="h-9 px-4 rounded-xl text-sm font-semibold btn-primary">Start free</button>
          </div>
        </div>
      </div>
    </nav>
  );
}

function Hero({ go }: { go: (h: string) => void }) {
  return (
    <section id="home" className="relative overflow-hidden pt-32 pb-20">
      <div className="absolute inset-0 bg-grid opacity-60" />
      <div className="aurora" />
      <div className="relative mx-auto max-w-6xl px-4 text-center">
        <div className="inline-flex items-center gap-2 glass rounded-full px-3 py-1.5 text-xs font-medium mb-6">
          <span className="h-1.5 w-1.5 rounded-full bg-mint pulse-dot" />
          Live on Stripe · 30-day money back guarantee
        </div>
        <h1 className="text-5xl sm:text-6xl md:text-7xl font-black tracking-tight leading-[1.05]">
          Your outbound. <span className="grad-text">On autopilot.</span>
        </h1>
        <p className="mt-5 text-lg text-white/70 max-w-2xl mx-auto">
          Nocta.ai writes, tests and sends hyper-personalized cold email at scale.
          Built for B2B teams that want more replies, not more busywork.
        </p>
        <div className="mt-8 flex items-center justify-center gap-3 flex-wrap">
          <button onClick={() => go("dashboard")} className="h-12 px-6 rounded-2xl btn-primary font-semibold text-[15px] shine relative overflow-hidden">Start free — no card needed</button>
          <button onClick={() => go("demo")} className="h-12 px-6 rounded-2xl glass font-semibold text-[15px]">▶ Watch 90s demo</button>
        </div>
        <div className="mt-4 text-xs text-white/50">Free 7-day trial · Cancel in 1 click · GDPR compliant</div>

        {/* Logos */}
        <div className="mt-14">
          <div className="text-[11px] uppercase tracking-[0.28em] text-white/40 mb-4">Trusted by revenue teams at</div>
          <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-3 text-white/50 font-bold tracking-wide">
            {["SEQUOIA","ACCEL","STRIPE LABS","Y COMBINATOR","NOTION","LINEAR","FIGMA","RAMP"].map(x => (
              <span key={x} className="text-sm">{x}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function ProductCard({ title, body, stat, emoji, tone }: any) {
  return (
    <div className="relative rounded-3xl p-6 glass overflow-hidden">
      <div className={`absolute -top-20 -right-20 h-64 w-64 rounded-full blur-3xl ${tone}`} />
      <div className="text-3xl">{emoji}</div>
      <div className="mt-3 font-bold text-xl">{title}</div>
      <p className="text-sm text-white/70 mt-2 leading-relaxed">{body}</p>
      <div className="mt-5 text-3xl font-black grad-text">{stat}</div>
    </div>
  );
}

function Product() {
  return (
    <section id="product" className="relative py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="max-w-2xl">
          <div className="text-xs font-semibold text-nocta-300 tracking-widest">PRODUCT</div>
          <h2 className="mt-3 text-4xl md:text-5xl font-black leading-tight">
            Everything your pipeline needs.<br /><span className="grad-text">In one place.</span>
          </h2>
          <p className="mt-4 text-white/70">
            Nocta replaces your cold-email tool, your CRM plugin, your AI writer and your list builder.
            One login, one bill, one dashboard that actually shows pipeline.
          </p>
        </div>
        <div className="mt-10 grid md:grid-cols-3 gap-4">
          <ProductCard emoji="🧠" tone="bg-nocta-500/30" title="AI email writer" body="Trained on 2B outbound emails. Writes 12 variants per prospect. Picks the best opener automatically." stat="2.3× replies" />
          <ProductCard emoji="🎯" tone="bg-accent/30" title="ICP targeting" body="Upload your ICP. Nocta finds 10,000 lookalike contacts with verified emails — instantly." stat="+312% pipeline" />
          <ProductCard emoji="📬" tone="bg-mint/20" title="Warmup & deliverability" body="Warm inboxes across 40 providers, auto-replies, spam score < 0.1. Out of the box." stat="99.2% inboxing" />
          <ProductCard emoji="📊" tone="bg-amber/30" title="Attribution" body="First-touch, multi-touch, and reply-to-revenue attribution across your whole stack." stat="1-click attribution" />
          <ProductCard emoji="🔁" tone="bg-nocta-400/30" title="Sequences" body="4-, 7- and 12-step multi-channel sequences: email + LinkedIn + Twitter, fully automated." stat="−68% manual work" />
          <ProductCard emoji="🛡️" tone="bg-mint/20" title="Compliance" body="GDPR, CAN-SPAM, CASL. Auto unsubscribe links, honorary opt-out lists, audit trails." stat="100% compliant" />
        </div>
      </div>
    </section>
  );
}

function Features() {
  const items = [
    ["⚡","Subject line AI","50 variants in 6 seconds. Nocta tests them live and keeps the winner."],
    ["🧭","ICP copilot","Describe the company you want — Nocta builds the list, scrubbed & verified."],
    ["🧾","Auto-personalization","Reads any website / LinkedIn. Writes lines that look human — because it learns from you."],
    ["📮","Smart sender rotation","10+ domains, warmup, staggered sends. Your deliverability is guaranteed."],
    ["🧱","A/B testing on rails","Variant testing on subject, opener, CTA, PS — with statistical significance."],
    ["🔌","50+ integrations","Hubspot, Salesforce, Pipedrive, Close, Slack, Zapier, Make, and your custom webhooks."],
  ];
  return (
    <section id="features" className="relative py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="text-xs font-semibold text-nocta-300 tracking-widest">FEATURES</div>
        <h2 className="mt-3 text-4xl md:text-5xl font-black leading-tight max-w-3xl">Built by ex-SDRs. <span className="grad-text">Loved by founders.</span></h2>
        <div className="mt-10 grid sm:grid-cols-2 md:grid-cols-3 gap-3">
          {items.map(([e, t, b]) => (
            <div key={t} className="glass rounded-2xl p-5">
              <div className="text-2xl">{e}</div>
              <div className="mt-2 font-bold">{t}</div>
              <div className="mt-1 text-sm text-white/70">{b}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Demo({ go }: { go: (h: string) => void }) {
  return (
    <section id="demo" className="relative py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="text-xs font-semibold text-nocta-300 tracking-widest text-center">LIVE DEMO</div>
        <h2 className="mt-3 text-4xl md:text-5xl font-black leading-tight text-center">Try Nocta, right here.</h2>
        <p className="mt-3 text-center text-white/70">Enter a prospect's website. Nocta will write a hyper-personalized cold email — live.</p>

        <DemoComposer />

        <div className="text-center mt-6">
          <button onClick={() => go("dashboard")} className="h-11 px-6 rounded-xl btn-primary font-semibold">See the real dashboard →</button>
        </div>
      </div>
    </section>
  );
}

function DemoComposer() {
  const [url, setUrl] = useState("linear.app");
  const [about, setAbout] = useState("Issue tracking for high-performance teams.");
  const [tone, setTone] = useState("Friendly & direct");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const generate = () => {
    setLoading(true);
    setResult(null);
    const openers = [
      `Hey ${url.split(".")[0][0].toUpperCase() + url.split(".")[0].slice(1)} team,`,
      `Quick one —`,
      `Heard about ${url.split(".")[0]}, cool stuff.`,
    ];
    const bodies = [
      `I noticed you folks focus on ${about.toLowerCase()} That's exactly the kind of team we help add $500K+ in outbound pipeline without hiring another SDR.`,
      `Most teams doing "${about.trim()}" lose ~40 hours a week writing cold email. We automate it and usually 2× reply rates in the first 30 days.`,
      `We just helped a company not unlike yours take outbound from $18K → $412K ARR in 4 months. Your stack looks like a fit.`,
    ];
    const ctas = [
      "Worth a 15-min call this week?",
      "Mind if I send over a 90-second personalized video?",
      "Should we chat — or should I not follow up?",
    ];
    setTimeout(() => {
      const o = openers[Math.floor(Math.random() * openers.length)];
      const b = bodies[Math.floor(Math.random() * bodies.length)];
      const c = ctas[Math.floor(Math.random() * ctas.length)];
      setResult(
`Subject: Quick one about ${url}

${o}

${b}

${c}

— Alex
Founder · nocta.ai
(Unsubscribe in 1 click)`.trim()
      );
      setLoading(false);
    }, 1100);
  };

  return (
    <div className="mt-8 grid md:grid-cols-2 gap-4">
      <div className="glass rounded-3xl p-6 space-y-4">
        <div>
          <label className="text-xs font-semibold text-white/60 uppercase tracking-wider">Prospect website</label>
          <input value={url} onChange={e => setUrl(e.target.value)} className="mt-2 w-full h-11 rounded-xl bg-white/5 border border-white/10 px-3 outline-none focus:border-nocta-400" placeholder="acme.com" />
        </div>
        <div>
          <label className="text-xs font-semibold text-white/60 uppercase tracking-wider">What they do</label>
          <textarea value={about} onChange={e => setAbout(e.target.value)} rows={3} className="mt-2 w-full rounded-xl bg-white/5 border border-white/10 p-3 outline-none focus:border-nocta-400" placeholder="Company summary / pitch..." />
        </div>
        <div>
          <label className="text-xs font-semibold text-white/60 uppercase tracking-wider">Tone</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {["Friendly & direct","Professional & concise","Warm & curious","Bold & short"].map(t => (
              <button key={t} onClick={() => setTone(t)} className={`h-8 px-3 rounded-full text-xs border ${tone===t ? "bg-white text-black border-white" : "bg-white/5 border-white/10 text-white/80"}`}>{t}</button>
            ))}
          </div>
        </div>
        <button onClick={generate} disabled={loading} className="w-full h-12 rounded-xl btn-primary font-semibold shine relative overflow-hidden disabled:opacity-70">
          {loading ? "✍️ Writing..." : "✨ Generate personalized email"}
        </button>
      </div>
      <div className="glass rounded-3xl p-6">
        <div className="flex items-center justify-between mb-3">
          <div className="flex gap-1.5">
            <span className="h-3 w-3 rounded-full bg-red-400/70" />
            <span className="h-3 w-3 rounded-full bg-amber-300/70" />
            <span className="h-3 w-3 rounded-full bg-mint/70" />
          </div>
          <span className="text-[11px] text-white/50">nocta.ai — live preview</span>
        </div>
        <div className="rounded-2xl bg-white/5 border border-white/10 p-4 min-h-[300px] text-[14px] leading-relaxed whitespace-pre-wrap">
          {loading ? (
            <div className="h-full grid place-items-center text-white/60">
              <div className="flex flex-col items-center gap-3">
                <div className="h-10 w-10 rounded-full border-2 border-white/10 border-t-nocta-400 animate-spin" />
                Nocta is researching {url}...
              </div>
            </div>
          ) : result ? (
            <div className="text-white/90">{result}</div>
          ) : (
            <div className="text-white/40 italic">Your email will appear here. Try the generator on the left — it works in under a second.</div>
          )}
        </div>
        {result && (
          <div className="mt-3 flex items-center gap-2 text-[11px] text-white/60">
            <kbd>⌘</kbd><kbd>C</kbd> to copy · <span className="ml-auto">Generated in 1.1s · Tone: {tone}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function Customers() {
  const quotes = [
    { who: "Jenna R.", role: "VP Sales · Series B SaaS", q: "We were paying 3 tools more. Switched to Nocta and reply rate went 2.1× in 30 days.", n: "2.1× replies" },
    { who: "Marcus L.", role: "Founder · B2B AI startup", q: "I was writing 60 emails a day. Now I press a button. Closed $182K in new pipeline first month.", n: "+$182K ARR" },
    { who: "Priya S.", role: "Head of Growth · Fintech", q: "Deliverability was our bottleneck. Nocta warmup + rotation — we haven't hit spam once.", n: "99.2% inboxing" },
  ];
  return (
    <section id="customers" className="relative py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="text-xs font-semibold text-nocta-300 tracking-widest text-center">CUSTOMERS</div>
        <h2 className="mt-3 text-4xl md:text-5xl font-black leading-tight text-center">$412M in pipeline generated.</h2>
        <div className="mt-10 grid md:grid-cols-3 gap-4">
          {quotes.map((x) => (
            <div key={x.who} className="glass rounded-3xl p-6">
              <div className="text-3xl font-black grad-text">“{x.n}”</div>
              <p className="mt-3 text-white/80 text-sm leading-relaxed">"{x.q}"</p>
              <div className="mt-5 pt-4 border-t border-white/10 text-sm">
                <div className="font-semibold">{x.who}</div>
                <div className="text-white/60 text-xs">{x.role}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Big stat panel */}
        <div className="mt-10 glass rounded-3xl p-8 overflow-hidden relative">
          <div className="aurora" />
          <div className="relative grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              ["412K","Leads generated"],
              ["9.4%","Avg reply rate"],
              ["<24h","Setup time"],
              ["4.9/5","Customer rating"],
            ].map(([v,k]) => (
              <div key={k}><div className="text-4xl md:text-5xl font-black grad-text">{v}</div><div className="mt-1 text-xs text-white/60">{k}</div></div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Affiliates() {
  return (
    <section id="affiliates" className="relative py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="relative rounded-3xl glass p-10 overflow-hidden">
          <div className="aurora" />
          <div className="relative grid md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="text-xs font-semibold text-nocta-300 tracking-widest">AFFILIATE PROGRAM · 40% RECURRING</div>
              <h2 className="mt-3 text-4xl font-black leading-tight">Recommend Nocta. Get paid forever.</h2>
              <p className="mt-3 text-white/70">Our partners earn an average of <b className="text-white">$4,812/mo</b> — paid monthly, recurring, for the lifetime of the customer.</p>
              <ul className="mt-5 space-y-2 text-sm text-white/80">
                <li>• 40% recurring commission on every plan</li>
                <li>• $200 bounty on Enterprise deals</li>
                <li>• Custom links, dashboard, creatives & co-branded landing pages</li>
                <li>• Payouts via Stripe, Wise or PayPal</li>
              </ul>
              <button className="mt-6 h-12 px-6 rounded-xl btn-primary font-semibold">Apply to the program →</button>
            </div>
            <div className="glass rounded-2xl p-6">
              <div className="text-xs font-semibold text-white/60 uppercase tracking-wider">Partner earnings — last 30 days</div>
              <div className="mt-3 text-4xl font-black grad-text">$14,820.41</div>
              <div className="mt-1 text-xs text-white/60">Payout: Jan 28 · via Stripe</div>
              <div className="mt-5 h-28 rounded-xl bg-white/5 border border-white/10 p-3">
                <svg viewBox="0 0 300 100" className="w-full h-full">
                  <defs>
                    <linearGradient id="lin" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="#8b5bff" stopOpacity="0.7" />
                      <stop offset="100%" stopColor="#8b5bff" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <path d="M0,80 C30,70 45,50 75,55 C105,60 120,30 150,25 C180,20 195,45 225,35 C255,25 270,10 300,15 L300,100 L0,100 Z" fill="url(#lin)" />
                  <path d="M0,80 C30,70 45,50 75,55 C105,60 120,30 150,25 C180,20 195,45 225,35 C255,25 270,10 300,15" fill="none" stroke="#b186ff" strokeWidth="2" />
                </svg>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                {[["412","Clicks"],["84","Signups"],["19","Paid"]].map(([v,k])=>(
                  <div key={k} className="rounded-xl bg-white/5 border border-white/10 p-3"><div className="text-lg font-black">{v}</div><div className="text-[10px] text-white/50">{k}</div></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  const [annual, setAnnual] = useState(true);
  const plans = [
    { name:"Starter", price: annual ? 29 : 39, tagline:"For founders validating outbound.", features:["1 seat","2,000 emails/mo","AI writer (basic)","ICP list builder","3 sequences","Community support"], cta:"Start free" },
    { name:"Growth", price: annual ? 99 : 129, tagline:"For growing revenue teams.", features:["5 seats","25,000 emails/mo","AI writer (pro)","ICP + lookalikes","Unlimited sequences","A/B testing","Deliverability warmup","Priority support","Slack + CRM integrations"], cta:"Start free", hot:true },
    { name:"Scale", price: annual ? 299 : 379, tagline:"For teams doing $5M+ ARR.", features:["Unlimited seats","250,000 emails/mo","AI writer (enterprise)","Dedicated warmup pool","SSO + SCIM","Audit logs","Dedicated CSM","Custom data residency","SLA 99.9%"], cta:"Talk to sales" },
    { name:"Enterprise", price: 0, tagline:"Custom. Talk to us.", features:["Everything in Scale","Custom contracts","On-prem / private cloud","White-label","Professional services","Custom billing"], cta:"Book a call" },
  ];

  return (
    <section id="pricing" className="relative py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="text-center">
          <div className="text-xs font-semibold text-nocta-300 tracking-widest">PRICING</div>
          <h2 className="mt-3 text-4xl md:text-5xl font-black">Simple plans. <span className="grad-text">No gotchas.</span></h2>
          <p className="mt-3 text-white/70">30-day money-back guarantee. Cancel in one click. Enterprise invoicing available.</p>
          <div className="mt-6 inline-flex glass rounded-full p-1 text-sm">
            <button onClick={() => setAnnual(false)} className={`px-4 h-9 rounded-full ${!annual ? "bg-white text-black font-semibold" : "text-white/80"}`}>Monthly</button>
            <button onClick={() => setAnnual(true)} className={`px-4 h-9 rounded-full ${annual ? "bg-white text-black font-semibold" : "text-white/80"}`}>Annual <span className="text-[10px] text-nocta-500 ml-1">save 25%</span></button>
          </div>
        </div>
        <div className="mt-10 grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {plans.map(p => (
            <div key={p.name} className={`relative rounded-3xl p-6 glass overflow-hidden ${p.hot ? "glow border-nocta-400/60" : ""}`}>
              {p.hot && <span className="absolute top-4 right-4 text-[10px] font-bold bg-nocta-500 text-white px-2 py-1 rounded-full">MOST POPULAR</span>}
              <div className="text-xs font-semibold text-nocta-300 tracking-widest">{p.name.toUpperCase()}</div>
              <div className="mt-3 flex items-baseline gap-1">
                {p.price > 0 ? (<><div className="text-5xl font-black">${p.price}</div><div className="text-sm text-white/60">/mo</div></>) : <div className="text-3xl font-black">Custom</div>}
              </div>
              <div className="text-sm text-white/70 mt-2">{p.tagline}</div>
              <ul className="mt-5 space-y-2 text-sm">
                {p.features.map(f => (
                  <li key={f} className="flex gap-2 text-white/85"><span className="text-mint">✓</span>{f}</li>
                ))}
              </ul>
              <button className={`mt-6 w-full h-11 rounded-xl font-semibold ${p.hot ? "btn-primary" : "bg-white text-black"}`}>{p.cta}</button>
            </div>
          ))}
        </div>

        {/* FAQ */}
        <div className="mt-20">
          <h3 className="text-2xl font-black text-center">Frequently asked</h3>
          <div className="mt-8 grid md:grid-cols-2 gap-3">
            {[
              ["Do I need a credit card to start?","No. Start free for 7 days. Cancel any time, one click."],
              ["Is this GDPR / CAN-SPAM compliant?","Yes. One-click unsubscribe, honorary opt-out lists, full audit trail."],
              ["Do you sell my data?","Never. Your data is yours. We don't train on your customer data."],
              ["Can I connect my own CRM?","HubSpot, Salesforce, Pipedrive, Close, Attio, and 50+ more. Custom webhooks too."],
              ["How long until I see results?","Most teams see meaningful pipeline in the first 30 days. We have a 30-day guarantee."],
              ["Do you offer agency / white-label plans?","Yes — the Enterprise tier supports white-label and agency pricing."],
            ].map(([q,a]) => (
              <details key={q} className="glass rounded-2xl p-5"><summary className="cursor-pointer font-semibold">{q}</summary><p className="mt-2 text-sm text-white/70">{a}</p></details>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function SignupBar() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="relative glass rounded-3xl p-10 overflow-hidden text-center">
          <div className="aurora" />
          <h3 className="relative text-4xl font-black leading-tight">Stop writing cold email.<br /><span className="grad-text">Start closing deals.</span></h3>
          <p className="relative mt-3 text-white/70">Try Nocta free for 7 days. No credit card. Cancel in one click.</p>
          <form className="relative mt-6 max-w-lg mx-auto flex gap-2" onSubmit={(e) => { e.preventDefault(); (e.currentTarget as HTMLFormElement).reset(); alert("Welcome! Check your email for your login link."); }}>
            <input required type="email" placeholder="you@company.com" className="flex-1 h-12 rounded-xl bg-white/5 border border-white/10 px-4 outline-none focus:border-nocta-400" />
            <button className="h-12 px-5 rounded-xl btn-primary font-semibold">Start free</button>
          </form>
          <div className="relative mt-3 text-xs text-white/50">Free 7-day trial · SOC 2 · GDPR · HIPAA-ready</div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const cols: [string, string[]][] = [
    ["Product", ["Overview","AI Writer","ICP Finder","Sequences","Deliverability","Integrations"]],
    ["Company", ["About","Customers","Careers","Changelog","Press kit"]],
    ["Resources", ["Docs","Guides","Cold email benchmarks","API reference","Status"]],
    ["Legal", ["Privacy","Terms","Security","DPA","Cookies","Data request"]],
  ];
  return (
    <footer className="relative mt-10 border-t border-white/5">
      <div className="mx-auto max-w-6xl px-4 py-12 grid md:grid-cols-5 gap-10">
        <div>
          <div className="flex items-center gap-2">
            <div className="relative h-8 w-8 rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-nocta-400 to-accent" />
              <span className="relative text-white font-black text-sm grid place-items-center h-full">N</span>
            </div>
            <span className="font-black text-lg">Nocta<span className="text-nocta-300">.ai</span></span>
          </div>
          <p className="mt-4 text-sm text-white/70">Outbound on autopilot. Built in Lisbon · San Francisco · Berlin.</p>
          <div className="mt-5 flex gap-2">
            {["𝕏","in","▶","📧"].map(s => (<button key={s} className="h-9 w-9 rounded-xl glass grid place-items-center">{s}</button>))}
          </div>
        </div>
        {cols.map(([title, items]) => (
          <div key={title}>
            <div className="text-xs font-bold uppercase tracking-widest text-white/60">{title}</div>
            <ul className="mt-4 space-y-2 text-sm text-white/80">
              {items.map(i => <li key={i} className="hover:text-white cursor-pointer">{i}</li>)}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/5">
        <div className="mx-auto max-w-6xl px-4 py-5 text-xs text-white/50 flex flex-wrap items-center justify-between gap-3">
          <div>© {new Date().getFullYear()} Nocta Labs, Inc. All rights reserved.</div>
          <div>Made with 💜 · v1.0.0 · 99.99% uptime</div>
        </div>
      </div>
    </footer>
  );
}

export default function Marketing({ go, section, setSection }: Props) {
  const nav = (h: string) => {
    setSection(h);
    const el = document.getElementById(h);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="relative">
      <Nav go={nav} />
      <Hero go={go} />
      <Product />
      <Features />
      <Demo go={go} />
      <Customers />
      <Affiliates />
      <Pricing />
      <SignupBar />
      <Footer />
      {/* Mobile anchor clicks — re-use section */}
      <div style={{ display: "none" }}>{section}</div>
    </div>
  );
}

import { useEffect, useState } from "react";
import Marketing from "./components/Marketing";
import Dashboard from "./components/Dashboard";

export default function App() {
  const [route, setRoute] = useState<"marketing" | "dashboard">("marketing");
  const [section, setSection] = useState<string>("home");

  useEffect(() => {
    const onHash = () => {
      const h = window.location.hash.replace("#", "");
      if (h === "dashboard") setRoute("dashboard");
      else {
        setRoute("marketing");
        setSection(h || "home");
      }
    };
    onHash();
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const go = (h: string) => {
    window.location.hash = h;
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (route === "dashboard") return <Dashboard go={go} />;
  return <Marketing go={go} section={section} setSection={setSection} />;
}

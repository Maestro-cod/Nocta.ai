# Export Compliance

Different app markets require different export-compliance declarations.
This file is a reference for developers and legal teams; it is not legal advice.

## United States — BIS / EAR

- The default Lumen build uses only standard cryptography (TLS / AES-256 / ECDHE).
- For apps that only use TLS and do not re-export proprietary crypto, a **Mass Market**
  exemption under ECCN 5D992.c typically applies.
- Most apps that qualify for the 5D992.c mass market exemption do **not** require an
  encryption registration with BIS, and Apple's App Store Connect Encryption question
  can typically be answered "No, it qualifies for an exemption" when the only crypto is
  HTTPS + standard at-rest AES.
- If you add custom crypto (non-standard algorithms, DRM, E2EE with custom protocols,
  license-managed crypto), file a **Self Classification Report** or obtain a CCATS before
  submitting.
- Do not ship to sanctioned regions (Crimea, Cuba, Iran, North Korea, Syria, and
  designated regions of Ukraine) unless you have specific OFAC authorization.

## European Union — EU Dual-Use Regulation

- Standard TLS + AES is generally not considered "dual-use" under the EU Dual-Use
  Regulation (EU) 2021/821.
- If you ship cryptographic software beyond "mass market" (e.g., E2EE tools with strong
  non-standard crypto for "sensitive use"), consult EU Dual-Use Annex I and seek a legal
  opinion.

## App Store Connect Questions (Apple)

Typical answers for the default Lumen build:

> Q: Does your app use encryption?
> A: Yes.
>
> Q: Is your app exempt from the encryption registration requirement?
> A: Yes — uses only HTTPS / TLS and standard at-rest AES, exempt under Note 4 for Category 5, Part 2 of EAR (BIS).
>
> Q: Does your app qualify for one or more exemptions under U.S. law?
> A: Yes.
>
> Q: Please confirm your app is not designed for end-uses prohibited by EAR Part 744, including
>    nuclear, chemical, or biological weapons, or missile technology proliferation.
> A: Confirmed.

## Google Play

Google Play does not require the same detailed crypto form, but you should
declare in your privacy policy that your app uses standard TLS and AES.

## Canada, UK, Australia, Japan

Each has broadly similar "mass market" exemptions; however the specifics
vary. For a worldwide launch, obtain a local legal opinion in:

- Canada — Export and Import Permits Act (EIPA)
- United Kingdom — UK Strategic Export Control Lists
- Australia — Defence and Strategic Goods List (DSGL)
- Japan — Foreign Exchange and Foreign Trade Act (FEFTA)

## Content compliance — other

- **COPPA (US)** — app is marked 13+; kids profile requires parental consent.
- **GDPR (EU)** — lawful basis documented per `PRIVACY.md`; DPO contact `privacy@lumen.app`.
- **CCPA / CPRA (CA, US)** — users may request deletion via in-app settings.
- **LGPD (Brazil)**, **PDPA (Singapore)**, **POPI (South Africa)**: same controls apply; the
  delete / export / opt-out mechanisms documented in `PRIVACY.md` satisfy most rights-based
  regimes.

## Checklist before each release

- [ ] Confirm no new custom crypto was added.
- [ ] Confirm no new third-party SDKs were added (or their data handling is declared).
- [ ] Confirm Privacy Policy and Data Safety form still match actual behavior.
- [ ] For iOS: attach annual US encryption self-classification if required by App Store.
- [ ] For Android: no further action if only TLS / AES; otherwise attach BIS CCATS.

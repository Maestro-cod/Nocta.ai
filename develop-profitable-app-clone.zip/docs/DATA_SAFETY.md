# Data Safety Form — Lumen (Google Play)

Use this file as a reference when filling out the **Data Safety** section in
the Google Play Console. The form is not optional; leaving items blank will
block your app from publication.

---

## 1. Does the app collect or share user data?

**Answer:** Yes.

## 2. Is all data transmitted over secure protocols?

**Answer:** Yes — all client ↔ server traffic uses HTTPS (TLS 1.2+). Audio / video
is streamed over HTTPS or TLS-protected WebRTC.

## 3. Does the app provide a way for users to request deletion of their data?

**Answer:** Yes — in-app via **Settings → Privacy → Delete my account**. Also via email to
`privacy@lumen.app`.

## 4. Data types you collect & process

Tick only the boxes you actually process. Lumen's default set:

| Data type          | Collected | Shared | Processed       | Notes (purpose)                           |
| ------------------ | :-------: | :----: | --------------- | ----------------------------------------- |
| Name / username    | ✅        | 🚫*    | Service ops     | Public profile                            |
| Email              | ✅        | 🚫     | Account mgmt    | Login, receipts, security alerts         |
| Phone              | 🟡        | 🚫     | 2FA (opt-in)    | Only if user enables SMS 2FA             |
| Date of birth      | ✅        | 🚫     | Age gating      | Stored as YYYY only (not full DOB)       |
| Photos / videos    | ✅        | ✅**   | Service ops     | Public videos; private drafts not shared |
| Audio              | ✅        | ✅**   | Service ops     | Live rooms, video audio tracks           |
| Location (approx)  | 🟡        | 🚫     | Recommendations | IP-based, opt-in                          |
| Device ID          | ✅        | 🚫     | Push, analytics | Firebase installation ID; reset on logout|
| Purchase history   | ✅        | ✅***  | Service ops     | Google Play Billing tokens                |

*Username + public profile are by definition shared with other users.
**Public videos are visible to other users; private drafts are encrypted client-side.
***Payment tokens go directly to Google / Stripe — we never see card numbers.

## 5. Data handling — encryption

- [x] Data in transit: TLS 1.2+
- [x] Data at rest: AES-256
- [x] Private content: client-side encryption with per-device key
- [x] Private messages: end-to-end encryption in direct DMs

## 6. Data retention

- Public videos: while account is active + 30-day soft-delete.
- Email / account metadata: while account is active + 30 days after deletion, then permanent deletion.
- Financial records: 7 years (tax / accounting law).
- Log data: 90 days.

## 7. Children's data

- Default audience: **13+**.
- "Kids" profile available under parental control — more restrictive, collects fewer signals, no personalized advertising.
- If you become aware of an under-13 account, email `privacy@lumen.app`; we delete within 14 days.

## 8. Play Console declaration — copy / paste

> "Lumen collects minimal personal information (account email, username,
> optional date of birth, payment tokens processed by Google Play Billing)
> in order to operate the Service. Public videos you post are shared with
> other users. Private content and private messages are encrypted client-side
> or end-to-end. Analytics signals are aggregated and do not identify
> individuals. Users may export or delete their data at any time from
> Settings → Privacy, or by emailing privacy@lumen.app.
>
> Data is transmitted over HTTPS and encrypted at rest (AES-256). Retention
> periods are documented in our privacy policy (hosted on a public URL
> listed in the Play Console)."

## 9. Anti-fraud / security

- Automated anti-abuse systems analyze IP + device signals to prevent fraud.
- Data used for anti-fraud is not used for advertising.
- Retention for anti-fraud logs: 180 days.

## 10. Policy review check

- [ ] Declarations match what the app actually does.
- [ ] No "shadow" data collection (e.g., no third-party trackers injected on the fly).
- [ ] All third-party SDKs are declared in Play Console (Firebase, Stripe, Plausible, etc.).
- [ ] Third-party SDKs have their own published privacy policies; link them in your listing.
- [ ] Users are informed of collection at runtime (consent banner, opt-in analytics).

For anything else, open a repo issue with the label `play-store-declaration`.

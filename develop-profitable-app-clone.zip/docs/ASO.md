# App Store Optimization (ASO) — Lumen

The goal of ASO is to maximize organic install volume from the Play Store and
App Store by improving keyword rankings and conversion from listing → install.

## Title candidates

- "Lumen — Watch, Create, Shine"
- "Lumen — Short Videos & LIVE"
- "Lumen — Creator Entertainment"

## Keyword seed list (English)

Primary: **short video app**, creator, livestream, live dj, video editor,
premium entertainment, reels, short form, trending videos, for you

Secondary: **AI video effects**, captions, filters, background music, soundboard,
trending audio, vertical video, mobile editor, vlog, shorts

Tertiary: **subscription entertainment**, family streaming, offline downloads,
creator monetization, virtual gifts, live chat, community, kids safe videos

## Description template (Play Store — max 4000 chars; keep ~300 words)

> **Lumen** is the premium short-video entertainment app where creators and fans
> come together. Discover a personalized feed of cinematic, music, comedy, travel,
> food and LIVE moments. Record, edit with AI effects, and earn — keep up to 80%
> of revenue.
>
> ✨ *Why creators love Lumen:*
> - Snap-scrolling HD feed, ambient design, offline downloads
> - LIVE from anywhere — multi-guest rooms, virtual gifts, tipping
> - Creator Studio: schedule, analytics, merch, captions, AI effects
> - Verified badge program — earn more the more you create
>
> 👪 *For families:* dedicated kids & teen profiles, parental controls, shared
> offline library, up to 6 accounts on Lumen Family.
>
> 💎 *Lumen+ / Pro / Family:* ad-free, up to 4K, creator tools, analytics,
> advanced monetization. Cancel anytime.
>
> Join 12 million creators. Download Lumen today.
>
> *Lumen is a trademark of Lumen Labs, Inc. Third-party music is licensed or user-uploaded.*

## Icon & feature graphic

- `docs/assets/lumen-icon.svg` — 512×512, rounded with gradient play mark.
- `docs/assets/feature.svg` — 1024×500, title + phone mock + CTA.

## Conversion rate levers

1. **Icon clarity** — instantly recognizable as "video entertainment".
2. **Screenshots** — ordered by importance: feed → LIVE → create → profile → family.
3. **Promo video** — 30s vertical, high-energy, ends with CTA "Install Lumen".
4. **Ratings** — 4.5+ target; auto-prompt after 5 successful uploads.
5. **Reply to reviews** — within 24 hours; turns negatives into neutrals.

## ASO measurement

- Weekly: check keyword rankings (tools: AppTweak, Sensor Tower, App Annie).
- Monthly: A/B test title, icon, feature graphic, screenshots via Play Store Experiments.
- Quarterly: refresh the full description based on new features.

## Avoid

- Keyword stuffing in title (Google will reject).
- Misleading screenshots (must match actual app UI).
- Price claims in screenshots unless you also display Play-Store-style fine print.
- Competitor trademarks in metadata unless you have license.

## Multilingual

Translate metadata for top markets: `en-US`, `es-ES`, `pt-BR`, `hi-IN`, `ja-JP`, `id-ID`,
`de-DE`, `fr-FR`, `it-IT`, `ar-SA`, `ko-KR`, `ru-RU`, `th-TH`, `tr-TR`, `vi-VN`.

# Google Play Store — Publishing Checklist ✅

This document walks through packaging **Lumen** for the Google Play Store and
keeping it compliant with Google Play Developer Policy and the EU's Digital
Services Act. Treat this as a living document: as policy updates land in the
Play Console, revisit this checklist.

---

## 1. Prerequisites

- [ ] Google Play Console account ($25 one-time developer fee)
- [ ] Legal entity (company / LLC) name, physical address, EU representative if selling in the EU
- [ ] Verified email and phone number (Google enforces 2FA as of 2024)
- [ ] D-U-N-S or equivalent if you plan to offer paid subscriptions
- [ ] Google Ads / Google Merchant Center accounts (optional, for ad-funded monetization)

## 2. Choose your Android wrapper

This repo ships a pure PWA-style web front-end. To get a signed APK / AAB
for the Play Store, pick one of these:

### Option A — Capacitor (recommended)
```bash
npm i -D @capacitor/core @capacitor/cli @capacitor/android
npx cap init Lumen com.lumen.app --webDir=dist
npx cap add android
npm run build && npx cap sync && npx cap open android
```
Then build signed AAB in Android Studio.

### Option B — TWA (Trusted Web Activity)
Best if you want a very thin Android shell that points at your deployed web app.
Requires assetlink.json on your domain. Use
[`@bubblewrap/cli`](https://github.com/GoogleChromeLabs/bubblewrap) to generate.

### Option C — React Native / Kotlin (greenfield)
Not required but possible. Keep the UI identical to this web shell.

## 3. AndroidManifest basics

Target SDK must be **34+** (Google's 2024+ requirement). Example snippet:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.lumen.app">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.CAMERA" android:required="false" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" android:required="false" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" android:required="false" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" android:required="false" />

    <application
        android:label="Lumen"
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Lumen"
        android:usesCleartextTraffic="false"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:networkSecurityConfig="@xml/network_security_config">
    </application>
</manifest>
```

## 4. App signing + AAB

- [ ] Generate an upload key: `keytool -genkeypair -alias upload -keyalg RSA -keysize 2048 -validity 9125 -keystore keystore.jks`
- [ ] In Android Studio, choose **Build → Generate Signed App Bundle / APK**.
- [ ] Produce an **AAB** (not APK) — smaller, Google signs and optimizes per-device.
- [ ] Upload first release to **Internal Testing → Closed Testing → Production**.
- [ ] Back up your keystore **offline**; losing it means losing the app.
- [ ] Opt in to **Play App Signing** — Google manages the release key; you keep the upload key.

## 5. Store listing (marketing assets)

| Asset                  | Spec                                       | Notes                                                              |
| ---------------------- | ------------------------------------------ | ------------------------------------------------------------------ |
| App title              | max 30 chars                               | "Lumen — Watch, Create, Shine"                                    |
| Short description      | max 80 chars                               | "Premium short-video entertainment. Creator-first."               |
| Full description       | max 4000 chars (keep ~300)                | Use bullet points. Mention HD, LIVE, creator tools, family mode. |
| Icon                   | 512×512 PNG 32-bit                         | See `docs/assets/lumen-icon.svg` (re-export to PNG at 512)       |
| Feature graphic        | 1024×500 PNG                               | Bold title, app UI mock, clear CTA — `docs/assets/feature.svg`   |
| Phone screenshots      | 3–8 images, 1080×1920 or 1440×2560        | Show feed, creator, profile, premium plans, LIVE, inbox          |
| Tablet screenshots     | 3–8 images, 1280×800 or 1920×1200         | Show 2-column explore grid                                         |
| Promo video (optional) | YouTube URL                                | 30–60s, no outside links, music under license                    |
| App category           | Social / Entertainment                     | Pick one; align with content rating                                |
| Content rating         | IARC questionnaire result                  | Be honest; children / family profiles must be separately rated    |
| Target audience        | Age ≥ 13 with optional kids profiles       | Document age-gating in app                                         |
| Contact / website      | Real URL + email                           | Host `PRIVACY.md` and `TERMS.md` as public pages                 |

## 6. Policy & form declarations

- [ ] **Privacy policy URL** in Play Console. Host on a public page and **inside the app** (Settings → Privacy).
- [ ] **Data Safety form** — answer using `docs/DATA_SAFETY.md` as a reference.
- [ ] **Ads declaration** — mark "Yes" if you show ads; "No" if pure subscription.
- [ ] **Monetization** — set up Google Play Billing Library (**v6+ required**) for subscriptions.
- [ ] **In-app purchases (SKUs)** — create SKU IDs for `lumen_plus_monthly`, `lumen_pro_yearly`, `lumen_family`.
- [ ] **Device exclusion** (optional) — exclude devices without camera if you rely on it for core creator features.
- [ ] **App accessibility** — declare whether your app is optimized for screen readers. Most Tailwind-heavy apps are acceptable if you ship aria-labels.
- [ ] **Content guidelines** — no hate, no sexual content, no gambling, no dangerous acts, no misleading medical advice.
- [ ] **Export compliance** — file for US BIS (EAR) encryption registration; typically, a "mass market" exemption applies for TLS-only apps.

## 7. Roll-out

- [ ] Internal Test → invite your team, 100 testers max.
- [ ] Closed Test (Alpha) → up to 1000 testers via email list or Google Groups.
- [ ] Open Test → anyone with the link can install.
- [ ] Production → staged rollout (1% → 10% → 50% → 100%) over at least 7 days.
- [ ] Monitor Android Vitals: crash rate, ANRs, startup time, battery use.
- [ ] Respond to reviews within 24 hours; reply thoughtfully to 1-star reviews.

## 8. Continuous delivery

- [ ] Fastlane for release automation: `fastlane supply` uploads AAB, changelog, screenshots.
- [ ] GitHub Actions job: build → sign → upload to Play Internal Test track.
- [ ] Changelog (`fastlane/metadata/android/en-US/changelogs/`) — 500 chars max per version.
- [ ] Proguard / R8 on native code: `minifyEnabled true`, keep `androidx.webkit.**` for WebView.
- [ ] Network Security Config: pin your API domain; block cleartext.
- [ ] App Startup / Baseline Profiles — to keep TTI (Time To Interactive) under 1s.

## 9. Useful resources

- [Google Play Policy Center](https://play.google.com/about/developer-content-policy/)
- [Data safety form help](https://support.google.com/googleplay/android-developer/answer/10787469)
- [Google Play Billing Library](https://developer.android.com/google/play/billing)
- [Capacitor docs](https://capacitorjs.com/docs)
- [Bubblewrap / TWA](https://developer.chrome.com/docs/android/trusted-web-activity/)
